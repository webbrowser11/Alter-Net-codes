## linureOS
operating system made by Alter Net codes

## Description
An os built FROM SCRATCH!! Its written in python a very easy langauge to learn and to program in!

## Contributing!
though this project is open-source will only be devloped by Alter Net codes

## report a bug
contact here:
terpstragraham@gmail.com
milo.c.3170@gmail.com

## Other information
WIP! work sitll in progress (not as much as SkyOS but probably hopefilly more now that the team can eaisily contribute at any time toghether and have conversation.)

written from SCRATCH!
