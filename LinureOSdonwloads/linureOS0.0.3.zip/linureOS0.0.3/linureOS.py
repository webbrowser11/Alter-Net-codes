import sys
import time

a = 1

def delete_last_line():
    "Use this function to delete the last line in the STDOUT"

    #cursor up one line
    sys.stdout.write('\x1b[1A')

    #delete last line
    sys.stdout.write('\x1b[2K')

print("Welcome! -LinureOS-")
for i in range(3):
    print(".")
    time.sleep(1)
    delete_last_line()
    print("..")
    time.sleep(1)
    delete_last_line()
    print("...")
    time.sleep(1)
    delete_last_line()
while(True):
    command = input("Enter command:")
    if command == "clear":
      for i in range(a):
        delete_last_line() 
    elif command == "help":
        print("clear-clears all of the screen")
        print("help-to learn all of the commands in this OS")
        print("shutdown-to shutdown this OS")
        print("calc.lexe-opens the calculator")
        print("linver.lexe-shows you the version of your OS")
    a = a+3
    elif command == "linver.lexe":
        print("linureOS version 0.0.3")
        print("OS build 0.2")
    elif command == "calc.lexe":
        def calculator():
            while True:
        # Print options for the user
                print("Enter '-' to subtract two numbers")
        print("Enter '+' to subtract two numbers")
        print("Enter '*' to multiply two numbers")
        print("Enter '/' to divide two numbers")
        print("Enter 'quit' to end the program")
        
        # Get user input
        user_input = input(": ")

        # Check if the user wants to quit
        if user_input == "quit":
            break
        # Check if the user input is a valid operator
        elif user_input in ["+", "-", "*", "/"]:
            # Get first number
            num1 = float(input("Enter a number: "))
            # Get second number
            num2 = float(input("Enter another number: "))

            # Perform the operation based on the user input
            if user_input == "+":
                result = num1 + num2
                print(num1, "+", num2, "=", result)

            elif user_input == "-":
                result = num1 - num2
                print(num1, "-", num2, "=", result)

            elif user_input == "*":
                result = num1 * num2
                print(num1, "*", num2, "=", result)

            elif user_input == "/":
                result = num1 / num2
                print(num1, "/", num2, "=", result)
        else:
            # In case of invalid input
            print("Invalid Input")

    # Call the calculator function to start the program
    calculator()
    elif command == "suutdown":
        print("see you later!")
        break
    else:
        print("sorry not a command. type help for a list of commands.")
